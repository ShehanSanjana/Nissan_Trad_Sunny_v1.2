<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST["submit_message"])) {
    $full_name = $_POST["full_name"]; 
    $email = $_POST["email"]; 
    $message_text = $_POST["message_text"];

    require_once "database.php";

    $sql = "INSERT INTO messages (full_name, email, message_text) VALUES (?, ?, ?)";
    $stmt = mysqli_stmt_init($conn);

    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, "sss", $full_name, $email, $message_text);
        if (mysqli_stmt_execute($stmt)) {
            echo '<script>alert("Message submitted successfully");</script>';
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Statement preparation failed: " . mysqli_error($conn);
    }
    header("Location:../WEB/index2.php");
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
