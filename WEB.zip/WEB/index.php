<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        Nissan Trad Sunny
    </title>
    <link rel="icon" href="Images/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>
</head>
<body>
    <header class="header">
        <a href="#" class="logo" style="font-family: 'Copperplate', 'Papyrus', fantasy; font-size: 30px; font-weight: bold;">Shehan's Cars....</a>
        <nav class="navbar">
        
            <a href="#" class="active">Home</a>
            <a href="#family">Family</a>
            <a href="#history">History</a>
            <a href="#models">Models</a>
            <a href="#engines">Engines</a>
        </nav>
        <div>
            <a style="color: white; font-size: 20px; font-weight: bold;">Hello!</a>
        </div>
    </header>
    <br><br><br>
    <selection class="Home">
        <div class="Home-content">
            <h1>
                Trad Sunny
            </h1>
            <h3>
                Ride with the wind
            </h3>
            <p  style="font-family: 'Tahoma', 'Verdana', 'sans-serif'; font-size: 17px" >
                Nissan B12 is one of the most successful car series by Nissan. Nissan Sunny B12 is also known as Nissan Trad Sunny.
                In Japan it was marketed as the TRAD Sunny...TRAD being the wierd Japanese-cool abbreviation for TRADITIONAL.
                The tradition of the Sunny was to be a mid-sized family sedan that offered best in class features and comfort that
                was on the edge of contemporary technology. If you look at B210/211, B310 Sunny you will realise that they are much more engaging,
                had far better technical advances and features than that of its competitiors such as the Corolla and the Lancer.  However, with
                the B11 series Sunny, the tradition of Sunny was felt to be lost. It was small, did not look beautiful, felt cheap. In fact it felt
                more like an entry level sedan and people drew similarities with the Datsun Cherry. With the B12 Sunny Nissan wanted to go back to
                the old tradition of the sunny...so they started a PR campaign titles TRAD Sunny. 
            </p>

            <div>
            <form action="message.php" method="post">
                <input type="text" name="full_name" placeholder="Name" style="width: 100%; padding: 5px; margin-bottom: 5px; border: 1px solid #ccc; border-radius: 5px;">
                <input type="email" name="email" placeholder="Email" style="width: 100%; padding: 5px; margin-bottom: 5px; border: 1px solid #ccc; border-radius: 5px;">
                <textarea name="message_text" placeholder="Enter your message" style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 5px;"></textarea>
                <input type="submit" name="submit_message" value="Send Message" style="background-color: #007bff; color: #fff; border: none; border-radius: 5px; padding: 10px 20px; cursor: pointer;">
            </form>

            </div>
            
        </div>
        
        <div style = "position: relative; left: 120px; top: 50px">
            <img src="Images/Background.jpg" height="300px" width="430px" align="right">
            <span class="home-imghover"></span>
            <div class="slider">
                <div><img src="Images/s4.jpg" alt="Image 1"></div>
                <div><img src="Images/s5.jpg" alt="Image 5"></div>
            </div>
        </div>
            
    </selection>
    <section id="family">
        <h1>Nissan Sunny B12 Family</h1>
        <p class="tabbed-paragraph">        The Nissan Sunny is an automobile built by the Japanese automaker Nissan from 1966 to 2006. In the early 1980s,
            the brand changed from Datsun to Nissan in line with other models by the company. Although production of the Sunny 
            in Japan ended in 2006, the name remains in use in China and GCC countries for a rebadged version of the Nissan Almera.
            In North America, the later models were known as the Nissan Sentra; in Mexico, the Sunny is known as the Nissan Tsuru, 
            which is Japanese for the bird species "crane". The latest versions of the Sunny were larger than the early models, 
            and may be considered compact cars. Earlier versions (through at least the B11 series) were subcompact cars. All Sunnys 
            through the 1982 model year (except as noted below) used Nissan A engine motors. It was designed to compete with the 
            Toyota Corolla.
            The "Sunny" name has been used on other Nissan models, notably various export versions of the Nissan Pulsar model line. 
            The Sunny has been imported and later manufactured worldwide under numerous names, and body styles, in economical, 
            luxury and performance packages. Some configurations appear to be unique based on bodystyle appearances, but sharing 
            a common platform. The Sunny was sold in Japan at a dedicated dealership sales channel called Nissan Satio Store, and 
            rebadged versions later appeared at the other Japanese networks.</p>
            <p class="tabbed-paragraph">Introduced in September 1985 at the Tokyo Motor Show, the B12 was not as widely exported, apart from the station wagon
            model and to some extent the RZ-1 coupé. This line is characterized by its squared-off styling, which was rather unfashionable
            by the mid-1980s. The angular styling was insisted upon by Nissan's design chief at the time and contributed to the automaker's
            increasingly poor sales of the period. A four-wheel-drive variant was introduced during this generation.
            In October 1986, European markets saw the B11 Sunny replaced by a rebadged N13 Pulsar in hatchback and saloon 
            form (the hatchback replacing the previous N12 Pulsar, which had been sold as the Cherry in this market). 
            These were sold alongside the B12 Sunny estate and coupé. In some markets, such as Greece, the N13 Pulsar 
            retained the "Cherry" nameplate. In the UK the B12 was sold as the Nissan Sunny Estate with a 1.6L engine. 
            The B12 Coupé (RZ-1) was also imported, with either 1.6 L or 1.8 L 16v engines.</p>
            <br><br>
    </section>
    
    <section id="history">
        <div class="content">
            <h1>Nissan Sunny History</h1>
            <p class="tabbed-paragraph">
                B10 (1966–1969)<br>
                B110 (1970–1973)<br>
                B210 (1973–1977)<br>
                B310 (1977–1981)<br>
                B11 (1981–1985)<br>
                B12 (1986–1989)<br>
            </p>
        </div>
        <div class="photo">
            <img id="draggableImage" src="Images/Background2.jpg" alt="Photo">
        </div>
    </section>
    
    <section id="models">
        <h1>Nissan Sunny B12 Models</h1>
    <p class="tabbed-paragraph">
        B12<Br>
        FB12<Br>
        HB12<Br>
        CB12<Br>
        SB12<Br>
        KB12
    </p>
    <br> <br>
    </section>
    

    
    <section id="engines">
        <h1>Nissan Sunny B12 Engines</h1>
    <p class="tabbed-paragraph">
1270 cc E13S I4 (B12)<Br>
1487 cc E15S/E I4 (HB12)<Br>
1487 cc E15ET turbo I4 (HB12)<Br>
1497 cc GA15S/E I4 (FB12)<Br>
1597 cc E16S/i/E I4 (KB12)<Br>
1598 cc CA16DE DOHC I4 (EB12)<Br>
1809 cc CA18DE DOHC I4<Br>
1680 cc CD17 diesel I4 (SB12)<Br>
    <br><br><br>
    </p>
    </section>
        <h4>
        <p>
            If you need more info about popular cars, contact me.
            <br>
        </p>
        </h4>

        <div class="btn-box">
            <a href="logout.php" class="btn btn-warning">Logout</a>
        </div>
        <br>

        <div class="home-sci">         
            <a href="https://web.facebook.com/profile.php?id=100008885950561"><i class="bx bxl-facebook"></i></a>
            <a href="https://twitter.com/ShehanSanjana2"><i class="bx bxl-twitter"></i></a>
            <a href="https://lk.linkedin.com/"><i class="bx bxl-linkedin"></i></a>
        </div>
    <script src="script.js"></script>
    <script src="draggableimage.js"></script>
    <script src="smooth-scroll.js"></script>
    
        
    </div>
</body>
</html>