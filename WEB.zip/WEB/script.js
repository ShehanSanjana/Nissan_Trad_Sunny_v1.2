
document.addEventListener("DOMContentLoaded", function() {

    var sliderImages = document.querySelectorAll(".slider img");
    var currentImage = 0;
  
    function showNextImage() {
      sliderImages[currentImage].style.display = "none";
      currentImage = (currentImage + 1) % sliderImages.length;
      sliderImages[currentImage].style.display = "block";
    }

    setInterval(showNextImage, 2000);
  });
  function closePopup() {
    document.getElementById('popup').style.display = 'none';
}


function closeDialog() {
  document.getElementById("success-dialog").style.display = "none";
}
  